# Morph Gate39 quick reference

Copy Morph_Gate39_Quick_Reference.pdf into your repository docs/ folder. Editable source: reference.py plus assets/. Regenerate with Python, ReportLab and Pillow (pip install reportlab pillow), then python reference.py. Uses Liberation Sans from the system fonts folder; adjust the two font paths for macOS.

Independent Morph guide. Hardware overview supplied by the owner; no TE endorsement implied. Screen examples are reconstructed renders, not camera captures. Gate39 features accepted by owner on hardware. Original guide extended with M3, MIDI and HUD delay; production firmware/source not changed.
