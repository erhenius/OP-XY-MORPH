#include <cstdio>
#include "display.cpp"
static int page=1,bank=0,module=0;
extern "C" opxy::i32 sdk_control_display(opxy::u32 i){return i==4?page:i==5?0xfc:i==6?bank:0;}
extern "C" bool sdk_morph_hud_snapshot_read(opxy::u32,morphcapture::hud::Snapshot* out){*out={};out->abi=morphcapture::hud::kSnapshotABI;out->captured_a=255;out->captured_b=255;out->mode=1;out->travel=32;out->track=0;out->module=module;out->start_ready=1;out->edit_side=0;for(unsigned i=0;i<26;++i){out->a[i]=0x20000000;out->s[i]=0x40000000;out->b[i]=0x60000000;out->current[i]=0x50000000;}for(unsigned i=0;i<4;++i)out->m1.primary[i]=i;return true;}
int main(){
 for(int scene=0;scene<3;++scene){page=1;module=scene;bank=0;
  morphcapture::Frame f={};morphcapture::DisplayState s={};opxy::draw::Input in={};in.track=0;
  morphcapture::display(s,in,f);
  std::printf("FRAME %d\n",scene);
  for(unsigned i=0;i<f.node_count;++i){auto n=f.nodes[i];std::printf("N %u %d %d %d %d %d\n",i,n.x,n.y,n.scale,n.cos,n.sin);}
  for(unsigned i=0;i<f.text_count;++i){auto t=f.texts[i];std::printf("T %u %d %d %d %s\n",i,t.x,t.y,t.scale,t.chars);}
 }
}
