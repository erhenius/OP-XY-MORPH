from pathlib import Path
from reportlab.pdfgen import canvas
from reportlab.lib.colors import Color,HexColor
from reportlab.lib.utils import ImageReader
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from PIL import Image
import textwrap
R=Path(__file__).parent;A=R/'assets';W,H=842,595
BG=HexColor('#110f11');WHITE=HexColor('#eeeeee');MUTED=HexColor('#b3b3b5');LINE=HexColor('#666469')
for name,f in [('Regular','/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf'),('Bold','/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf')]:pdfmetrics.registerFont(TTFont(name,f))
C=canvas.Canvas(str(R/'Morph_Gate35_Quick_Reference.pdf'),pagesize=(W,H));C.setTitle('Morph | Screens & gestures | Gate35');C.setAuthor('Independent Morph reference')
SRC=ImageReader(str(A/'opxy_controls.png'))
BOX={'INST':(49,234,142,326),'AUX':(142,234,235,326),'TEMPO':(328,141,422,234),'SHIFT':(235,514,328,606),'BAR':(1540,327,1632,420),'REC':(49,420,142,513),'PLAY':(142,420,235,513),'K1':(825,79,951,201),'K2':(1012,79,1138,201),'K3':(1198,79,1324,201),'K4':(1384,79,1510,201)}
for i in range(4):BOX['M'+str(i+1)]=(422+i*93,234,515+i*93,326)
for i in range(8):BOX['T'+str(i+1)]=(794+i*93,234,887+i*93,326)
PAGE=0
# Coordinates below use a top-left design grid.
def text(x,y,s,size=11,color=WHITE,font='Regular'):
 C.setFillColor(color);C.setFont(font,size);C.drawString(x,H-y-size*.82,s)
def rule(x,y,w):C.setStrokeColor(LINE);C.setLineWidth(.5);C.line(x,H-y,x+w,H-y)
def wrap(x,y,s,width,size=11,color=WHITE,leading=None):
 leading=leading or size*1.35
 words=s.split();line='';lines=[]
 for word in words:
  trial=(line+' '+word).strip()
  if pdfmetrics.stringWidth(trial,'Regular',size)>width and line:lines.append(line);line=word
  else:line=trial
 if line:lines.append(line)
 for i,l in enumerate(lines):text(x,y+i*leading,l,size,color)
 return len(lines)*leading

def page(title,kicker):
 global PAGE
 PAGE+=1;C.setFillColor(BG);C.rect(0,0,W,H,fill=1,stroke=0)
 text(34,23,'MORPH / SCREENS & GESTURES',9,MUTED,'Bold');text(34,47,title,29,WHITE,'Bold');text(34,87,kicker,11,MUTED)
 rule(34,112,774)
def end():
 rule(34,559,774);text(34,570,'GATE35  /  Independent OP-XY reference  /  13 November 2026',8,MUTED)
 text(748,570,f'{PAGE:02d} / 06',8,MUTED);C.showPage()
def hardware(x,y,w):C.drawImage(SRC,x,H-y-w*656/1775,width=w,height=w*656/1775,mask='auto')
def button(key,x,y,size=37):
 x0,y0,x1,y1=BOX[key];scale=size/(x1-x0);hh=(y1-y0)*scale
 C.saveState();p=C.beginPath();p.rect(x,H-y-hh,size,hh);C.clipPath(p,stroke=0,fill=0)
 C.drawImage(SRC,x-x0*scale,H-y-hh-(656-y1)*scale,width=1775*scale,height=656*scale,mask='auto');C.restoreState()
 return size

def gesture(keys,x,y,verb='press',size=35,ordered=False):
 at=x
 for i,k in enumerate(keys):
  if i:
   text(at,y+12,'then' if ordered else '+',9,MUTED);at+=29 if ordered else 18
  button(k,at,y,size);text(at,y+size+4,k,8,MUTED)
  at+=size
 text(x,y+size+16,verb,8,WHITE)
 return at-x

def row(y,keys,title,detail='',verb='press',x=34,w=774,ordered=False):
 gw=gesture(keys,x,y+2,verb,ordered=ordered);tx=x+max(166,gw+16)
 text(tx,y+4,title,12,WHITE,'Bold')
 if detail:wrap(tx,y+24,detail,w-(tx-x)-5,10,MUTED)
 rule(x,y+68,w)
def screen(file,x,y,w,caption=None):
 h=w*220/480;C.setStrokeColor(LINE);C.setLineWidth(.6);C.rect(x-1,H-y-h-1,w+2,h+2,fill=0,stroke=1)
 C.drawImage(str(A/file),x,H-y-h,width=w,height=h)
 if caption:wrap(x,y+h+8,caption,w,9,MUTED)
 return h

def box(x,y,w,h,title,body):
 C.setStrokeColor(LINE);C.setLineWidth(.6);C.roundRect(x,H-y-h,w,h,4,stroke=1,fill=0)
 text(x+14,y+13,title,18,WHITE,'Bold');wrap(x+14,y+40,body,w-28,11,MUTED)

page('Find the controls','AUX holds Morph. The instrument HUD brings its snapshots beside the sound controls.')
hardware(34,130,774)
text(34,427,'K1 - K4',12,WHITE,'Bold');wrap(34,448,'The four encoders above the screen. Turn, press or hold as shown.',225,11,MUTED)
text(303,427,'M1 - M4',12,WHITE,'Bold');wrap(303,448,'The four module buttons below the screen. These are not encoder presses.',225,11,MUTED)
text(572,427,'T1 - T8',12,WHITE,'Bold');wrap(572,448,'The eight track buttons. In instrument mode, hold the selected track for its HUD.',235,11,MUTED)
text(34,520,'GESTURES',9,MUTED,'Bold');text(124,520,'press = click once    hold = keep down    turn = rotate    + = overlap    then = ordered',11)
end()

page('M1 / capture & move','Open AUX, select track 4 / CV holding Morph, then press M1.')
screen('aux-0.png',34,135,350,'Actual Gate35 renderer example. Counts show captured tracks; percentage points toward A or B.')
box(34,340,107,101,'A','Stored endpoint.')
box(155,340,107,101,'B','Stored endpoint.')
box(276,340,108,101,'S','Stored return point.')
wrap(34,466,'First morph: prepare a sound, press K1. Change the sound, press K2. Turn K4. Press K4 to return to S.',350,12)
rows=[(['K1'],'Capture A','All eight tracks.','press'),(['K2'],'Capture B','All eight tracks.','press'),(['K3'],'SET S','Store the return sound for all tracks.','press'),(['K4'],'Move toward A / B','Sound changes on enabled tracks only.','turn'),(['K4'],'LIVE / BYPASS','BYPASS returns enabled tracks to S.','press'),(['K1'],'Choose A / B for editing','Left selects A; right selects B.','turn')]
for i,(keys,t,d,v) in enumerate(rows):
 y=135+i*65;gw=gesture(keys,425,y,v,31);text(482,y+3,t,12,WHITE,'Bold');wrap(482,y+23,d,316,10,MUTED)
end()

page('M2 / routing     M4 / LFO','Capture includes every track. Routing decides which tracks Morph can change.')
screen('aux-1.png',34,135,350,'M2: dark lower boxes are OFF; white lower boxes are ON. Tracks 1-4 are controlled by the encoders.')
screen('aux-2.png',34,345,350,'M2: tracks 5-8 now have the four encoder shades. The route states stay the same.')
row(135,['M2'],'Open routing','Eight numbered columns show all instrument tracks.',x=425,w=383)
row(208,['K1'],'Enable / exclude a track','Turn its corresponding encoder: right ON, left OFF.',verb='turn K1-K4',x=425,w=383)
row(281,['K1'],'Switch 1-4 / 5-8','Click any encoder; the shaded headers identify the current bank.',x=425,w=383)
row(354,['M4'],'Open the stock LFO','Choose Morph, the fourth machine control, as destination. Set waveform, rate and amount with the stock LFO controls.',x=425,w=383)
wrap(425,442,'LFO movement requires LIVE. Manual BYPASS stays bypassed. Use slow modulation first; fast modulation can be stepped.',383,11)
wrap(425,502,'Excluded tracks stay at their current sound, including on return to S. Their A/B values remain capturable and editable.',383,10,MUTED)
end()

page('Instrument HUD / screen catalogue','Hold the selected instrument track. Release it to leave, unless the HUD is latched.')
for i,(name,cap) in enumerate([('M1','Synth controls'),('M2','AMP / FILTER'),('M3','Envelopes')]):
 x=34+i*265;screen('hud-'+str(i)+'.png',x,136,244,cap+' - renderer example values.');gesture([name],x,283,'select module',31)
text(34,361,'READ THE ROWS',10,MUTED,'Bold')
box(34,385,244,113,'A / B','Stored endpoint values for this track. The highlighted edit row is the one encoder turns change.')
box(299,385,244,113,'S','The stored starting/return values. S is not a live readout of the sound currently playing.')
box(564,385,244,113,'Movement','The meter shows travel toward A or B. Centre is the movement origin; it is not necessarily S.')
wrap(34,520,'Supported synth SHIFT parameters are captured and morphed too. Their M1 SHIFT fields are read-only in the HUD; existing key collisions remain.',774,10,MUTED)
end()

page('HUD / button combinations','For held-HUD SHIFT gestures: hold the instrument track first, then SHIFT, then the encoder.')
# Two columns of compact illustrated bindings.
left=[(['T1'],'Hold-to-open HUD','Use the selected T1-T8. Release to close.','hold'),
(['SHIFT','TEMPO'],'Latch / unlatch HUD','Hold SHIFT, then press TEMPO.','hold + press'),
(['INST'],'Clear the HUD latch','Return to the normal instrument page.','press'),
(['K1'],'Alternate page / bank','M1: available alternate row. M2: AMP / FILTER.','press'),
(['K2'],'Choose edit A / B','Select which stored row the encoders edit.','press'),
(['K1'],'Edit snapshot values','In BYPASS, turn K1-K4 for the visible fields.','turn K1-K4'),
(['K3'],'SET S','All eight tracks, independent of the edit row.','press')]
right=[(['K4'],'LIVE / BYPASS','Movement and return to S affect enabled tracks.','press'),
(['K4'],'Sweep','Keep K4 held while turning K4.','hold + turn'),
(['SHIFT','K1'],'Capture this track into A','Selected track only.','hold + press'),
(['SHIFT','K2'],'Capture this track into B','Selected track only.','hold + press'),
(['SHIFT','K3'],'Jump toward A','Release K3 while SHIFT remains held.','hold + release'),
(['SHIFT','K4'],'Jump toward B','Release K4 while SHIFT remains held.','hold + release'),
(['SHIFT','K3','K4'],'LIVE / BYPASS chord','K3 and K4 overlap; individual jumps are suppressed.','overlap')]
for col,items in [(34,left),(430,right)]:
 for i,(keys,t,d,v) in enumerate(items):
  y=136+i*57;gesture(keys,col,y,v,25)
  tx=col+151;text(tx,y+2,t,10.5,WHITE,'Bold');wrap(tx,y+19,d,225,9,MUTED,leading=11)

end()

page('Record, return, remember','Only physical movement on AUX M1 K4 is recorded as Morph automation.')
row(135,['REC','K4'],'Record movement','While the sequencer plays, hold RECORD and turn K4 on Morph AUX M1. Release RECORD; keep LIVE enabled for replay.',verb='hold + turn')
row(209,['K4'],'Return to S / manual bypass','Recorded movement and the LFO cannot automatically re-enable LIVE. Press K4 explicitly to enable it again.')
row(283,['BAR','M2'],'Erase parameter automation','Hold BAR, then press M2 on Morph AUX. Clears ALL parameter locks in this AUX pattern; retains notes and other tracks.',verb='hold + press',ordered=True)
box(34,374,244,149,'Save / reload','Keep project.xy and its .oxy companion together. The companion stores snapshots and the recording origin. After load, enable LIVE manually.')
box(299,374,244,149,'New context','Only the current snapshot bank is kept. Engine/schema, pattern or scene changes start a fresh bank. Switching away and back does not recall unsaved banks.')
box(564,374,244,149,'Everyday quirks','Startup captures once; AUX revisits do not recapture. Scramble refreshes that track\'s S and retains A/B. Capturing while LIVE returns enabled tracks to S.')
text(34,537,'SHIFT before track keeps stock menus. Track before SHIFT gives Morph gestures. Old scattered automation is not repaired automatically.',9,MUTED)
end();C.save()
