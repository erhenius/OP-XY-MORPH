from pathlib import Path
import json,hashlib,zipfile,shutil
from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer,Table,TableStyle
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from pypdf import PdfReader,PdfWriter
r=Path('deliverables/Morph_v1.3.0-dev_Git_Update');tmp=Path('preset-reference-addition.pdf')
styles=getSampleStyleSheet();story=[]
for text,style in [('Morph v1.3.0-dev / Gate40','Title'),('A/B presets and machine removal','Heading1'),('A/B presets on the XY','Heading2'),('Stop transport and select BYPASS. On Morph AUX M3, press K4 to open the preset panel. Slots AB 01-16 store both scenes across all eight tracks. S is excluded.','BodyText')]:story.extend([Paragraph(text,styles[style]),Spacer(1,12)])
t=Table([['Control','Preset panel action'],['K1 turn','Select AB 01-16'],['K2 press','Load A/B'],['K3 press twice','Save A/B; confirm within three seconds'],['K4 press','Return to pad controls']],colWidths=[130,350]);t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor('#222222')),('TEXTCOLOR',(0,0),(-1,0),colors.white),('GRID',(0,0),(-1,-1),.4,colors.lightgrey),('TOPPADDING',(0,0),(-1,-1),9),('BOTTOMPADDING',(0,0),(-1,-1),9)]));story += [t,Spacer(1,18)]
for title,text in [('Instrument compatibility','Matching instruments recall all supported scene parameters. A mismatched track recalls common M2/M3 controls while preserving its existing M1 and engine-specific SHIFT values in A/B. The panel identifies partial recalls. Presets store settings, not samples or instrument installations.'),('S and performance','Preset recall changes A/B only. S follows current stored instrument settings in BYPASS and stays frozen in LIVE except explicit SET S. Save/load requires stopped transport and BYPASS. No preset files are scanned in the background.'),('Machine removal in the installer','Select rows in Installed setup, then choose Remove selected installed machines. Keep selected installed machines undoes removal; Clear changes cancels pending edits. Calculate, Build and review before staging. User projects and presets are retained. Projects using removed machines need those machines reinstalled.'),('Updating this bundle','MultiFX SDK support is already integrated. Select Replace installed Morph to update your existing Morph; do not reimport already-installed MultiFX. Lists are alphabetical and installed machines are hidden from Available.'),('Development status','Host checks pass. Native firmware build, Mac GUI and device acceptance of this combined revision remain pending. Earlier pages describe inherited controls; this page supplies the Gate40 additions.')]:story.extend([Paragraph(title,styles['Heading2']),Paragraph(text,styles['BodyText']),Spacer(1,10)])
SimpleDocTemplate(str(tmp),pagesize=A4,rightMargin=40,leftMargin=40,topMargin=35,bottomMargin=35).build(story)
w=PdfWriter();w.append(PdfReader(r/'docs/Morph-Quick-Reference.pdf'));w.append(PdfReader(tmp));w.write(r/'docs/Morph-Quick-Reference.pdf')
shutil.copy2(r/'docs/Morph-Quick-Reference.pdf',r/'builder/Morph-Quick-Reference.pdf')
with zipfile.ZipFile(r/'docs/Morph-Reference-Source.zip','a',zipfile.ZIP_DEFLATED) as z:z.write('update_git_bundle.py','gate40_reference_update.py')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
p=r/'builder/PAYLOAD_SHA256.json';p.write_text(json.dumps({q.relative_to(r/'builder').as_posix():sha(q) for q in sorted((r/'builder').rglob('*')) if q.is_file() and q.name!='PAYLOAD_SHA256.json'},indent=2)+'\n')
p=r/'RELEASE_FILES_SHA256.json';p.write_text(json.dumps({q.relative_to(r).as_posix():sha(q) for q in sorted(r.rglob('*')) if q.is_file() and q!=p},indent=2)+'\n')
with zipfile.ZipFile(r.parent/'Morph_v1_3_0_dev_Git_Update.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(r.rglob('*')):
  if p.is_file():z.write(p,p.relative_to(r))
print('reference pages',len(w.pages))
